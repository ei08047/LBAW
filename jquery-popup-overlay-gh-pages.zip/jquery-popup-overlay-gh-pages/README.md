# jQuery Popup Overlay

jQuery plugin for responsive and accessible modal windows and tooltips.

## Documentation & demo
[Documentation & demo](http://vast-engineering.github.io/jquery-popup-overlay/)

## License
Released under the [MIT license](http://www.opensource.org/licenses/MIT).